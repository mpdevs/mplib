# coding: utf-8
# __author__: u"John"
from __future__ import unicode_literals, absolute_import, print_function, division
from mplib.Math.elementary_function import npr, ncr
from mplib.Math.helper import get_chunk_number
